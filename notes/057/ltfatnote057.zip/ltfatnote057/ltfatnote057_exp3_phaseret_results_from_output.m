% This file plots the results of the phaseless reconstruction experiment
% (Figure 8)reported in the paper 'Invertible grid-based sampling of wavelet 
% transforms for audio processing' by N. Holighaus, G. Koliander, C. Hollomey, and 
% F. Pillichshammer. 

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

%% Load results % COMMENT THIS IF YOU ACQUIRE RESULTS FROM AUDIO DATA 
load('./exp3_phaseret/wvlt_pr_results.mat');

if isoctave
   contains = @(str, pattern) ~cellfun('isempty', strfind(str, pattern));
end

% % UNCOMMENT THE ENTIRE COMMENTED BLOCK TO RECOMPUTE RESULTS FROM AUDIO DATA
% % Reference dictionary 1
% Ls = 5*44100;	
% alpha = 1000;
% filtNos = 180;
% red = 50;
% [gs,as,fc,L,info] = waveletfilters(Ls,2.^linspace(6,-3.3,filtNos),...
%     {'cauchy',alpha}, 'redtar', red,'uniform');
% 
% %% Reference dictionary 2
% a = 64; M = 3072;
% g = gabwin({'gauss',a*M/Ls},a,M,Ls);
% 
% 
% %% For Kronecker
% path = './exp3_phaseret/output_kron/'; % This is where the experiment output is located
% listing = dir([path,'*.flac']); % List all flac files
% filenames = arrayfun(@(El) El.name,listing,'UniformOutput',0);
% filenames = filenames(contains(filenames,'_ORG'));
% for kk = 1:numel(filenames)
%     filenames{kk} = filenames{kk}(1:end-9);
% end
% 
% patterns = {'_red_10_FGLIM_cauchy_1000.flac','_red_5_FGLIM_cauchy_1000.flac',...
%     '_red_3_FGLIM_cauchy_1000.flac','_red_1.8_FGLIM_cauchy_1000.flac'};
% 
% SConvKron = zeros(numel(filenames),numel(patterns));
% SConvGKron = zeros(numel(filenames),numel(patterns));
% 
% for kk = 1:numel(patterns)
%     for jj = 1:numel(filenames)
%         disp(['Computing for Kronecker condition (',num2str(kk),',',num2str(jj),')']);
%         fileOrg = audioread([path,filenames{jj},'_ORG.flac']);
%         fileRec = audioread([path,filenames{jj},patterns{kk}]);
%                 
%         cOrg = ufilterbank(fileOrg(1:Ls),gs,as);
%         cRec = ufilterbank(fileRec(1:Ls),gs,as);
%         
%         SConvKron(jj,kk) = 20*log10( norm(abs((cOrg)) - abs((cRec)),'fro' )/norm( abs((cOrg)),'fro') );
%         
%         cOrgG = dgtreal(fileOrg(1:Ls),g,a,M);
%         cRecG = dgtreal(fileRec(1:Ls),g,a,M);
%         
%         SConvGKron(jj,kk) = 20*log10( norm(abs((cOrgG)) - abs((cRecG)),'fro' )/norm( abs((cOrgG)),'fro') );
%     end
% end
% 
% %% For Classical
% path = './exp3_phaseret/output_class/'; % This is where the experiment output is located
% listing = dir([path,'*.flac']); % List all flac files
% filenames = arrayfun(@(El) El.name,listing,'UniformOutput',0);
% filenames = filenames(contains(filenames,'_ORG'));
% for kk = 1:numel(filenames)
%     filenames{kk} = filenames{kk}(1:end-9);
% end
% 
% patterns = {'_red_10_FGLIM_cauchy_1000.flac','_red_5_FGLIM_cauchy_1000.flac',...
%     '_red_3_FGLIM_cauchy_1000.flac','_red_1.8_FGLIM_cauchy_1000.flac'};
% 
% SConvClass = zeros(numel(filenames),numel(patterns));
% SConvGClass = zeros(numel(filenames),numel(patterns));
% 
% for kk = 1:numel(patterns)
%     for jj = 1:numel(filenames)
%         disp(['Computing for Classical condition (',num2str(kk),',',num2str(jj),')']);
%         fileOrg = audioread([path,filenames{jj},'_ORG.flac']);
%         fileRec = audioread([path,filenames{jj},patterns{kk}]);
%         
%         cOrg = ufilterbank(fileOrg(1:Ls),gs,as);
%         cRec = ufilterbank(fileRec(1:Ls),gs,as);
%         
%         SConvClass(jj,kk) = 20*log10( norm(abs((cOrg)) - abs((cRec)),'fro' )/norm( abs((cOrg)),'fro') );
%         
%         cOrgG = dgtreal(fileOrg(1:Ls),g,a,M);
%         cRecG = dgtreal(fileRec(1:Ls),g,a,M);
%         
%         SConvGClass(jj,kk) = 20*log10( norm(abs((cOrgG)) - abs((cRecG)),'fro' )/norm( abs((cOrgG)),'fro') );
%     end
% end
% 
% %% For Gabor
% path = './exp3_phaseret/output_gab/'; % This is where the experiment output is located
% listing = dir([path,'*.flac']); % List all flac files
% filenames = arrayfun(@(El) El.name,listing,'UniformOutput',0);
% filenames = filenames(contains(filenames,'_ORG'));
% for kk = 1:numel(filenames)
%     filenames{kk} = filenames{kk}(1:end-9);
% end
% 
% patterns = {'_red_10_FGLIM_hann1536.flac','_red_5_FGLIM_hann1536.flac',...
%     '_red_3_FGLIM_hann1536.flac','_red_1.8_FGLIM_hann1536.flac'};
% 
% SConvGab = zeros(numel(filenames),numel(patterns));
% SConvGGab = zeros(numel(filenames),numel(patterns));
% 
% for kk = 1:numel(patterns)
%     for jj = 1:numel(filenames)
%         disp(['Computing for Gabor condition (',num2str(kk),',',num2str(jj),')']);
%         fileOrg = audioread([path,filenames{jj},'_ORG.flac']);
%         fileRec = audioread([path,filenames{jj},patterns{kk}]);
%         
%         cOrg = ufilterbank(fileOrg(1:Ls),gs,as);
%         cRec = ufilterbank(fileRec(1:Ls),gs,as);
%         
%         SConvGab(jj,kk) = 20*log10( norm(abs((cOrg)) - abs((cRec)),'fro' )/norm( abs((cOrg)),'fro') );
%         
%         cOrgG = dgtreal(fileOrg(1:Ls),g,a,M);
%         cRecG = dgtreal(fileRec(1:Ls),g,a,M);
%         
%         SConvGGab(jj,kk) = 20*log10( norm(abs((cOrgG)) - abs((cRecG)),'fro' )/norm( abs((cOrgG)),'fro') );
%     end
% end

save('./exp3_phaseret/wvlt_pr_results.mat','SConvGGab','SConvGab','SConvGKron','SConvKron','SConvGClass','SConvClass');

%% Plotting and evaluation 

means = [mean(SConvKron,1);mean(SConvClass,1);mean(SConvGab,1);...
    mean(SConvGKron,1);mean(SConvGClass,1);mean(SConvGGab,1)];
medians = [median(SConvKron,1);median(SConvClass,1);median(SConvGab,1);...
    mean(SConvGKron,1);mean(SConvGClass,1);mean(SConvGGab,1)];

figure(1)
subplot(4,1,1);
plot([SConvKron(:,1),SConvClass(:,1),SConvGab(:,1)]);
title('FGLA at redundancy 10');
axis([1,15,-45,0])
subplot(4,1,2);
plot([SConvKron(:,2),SConvClass(:,2),SConvGab(:,2)]);
title('FGLA at redundancy 5');
axis([1,15,-45,0])
subplot(4,1,3);
plot([SConvKron(:,3),SConvClass(:,3),SConvGab(:,3)]);
title('FGLA at redundancy 3');
axis([1,15,-45,0])
subplot(4,1,4);
plot([SConvKron(:,4),SConvClass(:,4),SConvGab(:,4)]);
title('FGLA at redundancy 1.8');
legend('Kronecker','Classical','Gabor','Location','SouthEast');
axis([1,15,-45,0])


figure(2);
subplot(3,1,1);
plot([SConvKron(:,1),SConvKron(:,2),SConvKron(:,3),SConvKron(:,4)]);
title('FGLA for Cauchy Kronecker');
legend('10','5','3','1.8');
axis([1,15,-45,0])
subplot(3,1,2);
plot([SConvClass(:,1),SConvClass(:,2),SConvClass(:,3),SConvClass(:,4)]);
title('FGLA for Cauchy Classical');
legend('10','5','3','1.8');
axis([1,15,-45,0])
subplot(3,1,3);
plot([SConvGab(:,1),SConvGab(:,2),SConvGab(:,3),SConvGab(:,4)]);
title('FGLA for Gabor');
legend('10','5','3','1.8');
axis([1,15,-45,0])

figure(3)
subplot(4,1,1);
plot([SConvGKron(:,1),SConvGClass(:,1),SConvGGab(:,1)]);
legend('Kronecker','Classical','Gabor');
title('FGLA at redundancy 10 (Gabor reference)');
axis([1,15,-45,0])
subplot(4,1,2);
plot([SConvGKron(:,2),SConvGClass(:,2),SConvGGab(:,2)]);
title('FGLA at redundancy 5 (Gabor reference)');
legend('Kronecker','Classical','Gabor');
axis([1,15,-45,0])
subplot(4,1,3);
plot([SConvGKron(:,3),SConvGClass(:,3),SConvGGab(:,3)]);
title('FGLA at redundancy 3 (Gabor reference)');
legend('Kronecker','Classical','Gabor');
axis([1,15,-45,0])
subplot(4,1,4);
plot([SConvGKron(:,4),SConvGClass(:,4),SConvGGab(:,4)]);
title('FGLA at redundancy 1.8 (Gabor reference)');
legend('Kronecker','Classical','Gabor');
axis([1,15,-45,0])

figure(4);
subplot(3,1,1);
plot([SConvGKron(:,1),SConvGKron(:,2),SConvGKron(:,3),SConvGKron(:,4)]);
title('FGLA for Cauchy Kronecker (Gabor reference)');
legend('10','5','3','1.8');
axis([1,15,-45,0])
subplot(3,1,2);
plot([SConvGClass(:,1),SConvGClass(:,2),SConvGClass(:,3),SConvGClass(:,4)]);
title('FGLA for Cauchy Classical (Gabor reference)');
legend('10','5','3','1.8');
axis([1,15,-45,0])
subplot(3,1,3);
plot([SConvGGab(:,1),SConvGGab(:,2),SConvGGab(:,3),SConvGClass(:,4)]);
title('FGLA for Gabor (Gabor reference)');
legend('10','5','3','1.8');
axis([1,15,-45,0])


SConv_exp3(:,:,1)=SConvClass;

SConv_exp3(:,:,2)=SConvKron;

SConv_exp3(:,:,3)=SConvGab;



SConv_exp3min = squeeze(min(SConv_exp3,[],1));

SConv_exp3med = squeeze(median(SConv_exp3,1));

SConv_exp3max = squeeze(max(SConv_exp3,[],1));


figure(8);
hold on;
mainlinex = zeros(2,1);
mainliney = zeros(2,1);
ticklinex = zeros(2,1);
tickliney = zeros(2,1);
for ii = 1:3
    locy = ii+0.2; %y-axis location
    locxmin = SConv_exp3min(ii,1);
    locxmed = SConv_exp3med(ii,1);
    locxmax = SConv_exp3max(ii,1);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p1=plot(mainlinex,mainliney,'--r');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');

    locy = ii; %y-axis location
    locxmin = SConv_exp3min(ii,2);
    locxmed = SConv_exp3med(ii,2);
    locxmax = SConv_exp3max(ii,2);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p2=plot(mainlinex,mainliney,'-k');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');


    locy = ii-0.2; %y-axis location
    locxmin = SConv_exp3min(ii,3);
    locxmed = SConv_exp3med(ii,3);
    locxmax = SConv_exp3max(ii,3);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p3=plot(mainlinex,mainliney, '-.b');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');

end

yticks(1:4)
yticklabels({...
          '10', ...
          '5', ...
          '3', ...
          '1.8'
        })

legend([p1, p2, p3],{'Classical WL','Proposed WL','STFT'});
hold off;


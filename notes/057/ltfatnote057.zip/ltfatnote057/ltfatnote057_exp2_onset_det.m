% This file reproduces the onset detection experiment (Figure 7) in the paper
% 'Invertible grid-based sampling of wavelet transforms for audio processing' by
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer.
%
% This is the full computation, it requires the placement
% of the audiofiles from here: http://ltfat.github.io/notes/057/input_onset.zip in
% the same folder as this script.
% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible
% grid-based sampling of wavelet transforms for audio processing' by
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the
% Free Software Foundation, either version 3 of the License, or (at your
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
% for more details.
%
% You should have received a copy of the GNU General Public License along
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

%% Music and annotation data from:
% https://grfia.dlsi.ua.es/cm/projects/prosemus/database.php
% This code requires MIRtoolbox 1.8.1:
% https://www.jyu.fi/hytk/fi/laitokset/mutku/en/research/materials/mirtoolbox
%
% O. Lartillot, P. Toiviainen, and T. Eerola, “A Matlab toolbox for music
% information retrieval,” in Data Analysis, Machine Learning and Appli-
% cations, C. Preisach, H. Burkhardt, L. Schmidt-Thieme, and R. Decker,
% Eds. Berlin, Germany: Springer, 2008, pp. 261–268.


%% Prepare to load test signals
addpath('./exp2_onsets')
path = 'input_onset/'; % Place your test signal wav files here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,...
                       'UniformOutput',0);

path_annot = 'exp2_onsets/ground-truth_onset/'; % Place your annotations here
listing_annot = dir([path_annot,'*.txt']);
allannotCell = arrayfun(@(txt) fullfile(path_annot,txt.name),listing_annot,...
               'UniformOutput',0);



writepath_onset = 'exp2_onsets/output_onset/'; % The experiment output will be saved here
if ~exist(writepath_onset, 'dir')
       mkdir(writepath_onset)
end

% Golden Kronecker sequence
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

% Specify wavelet filterbank
start_index = 20;
M = 1012;
redundancy = 4;
cauch_alpha = 2700;
% Set maximum center frequency to Nyquist
max_freqDiv10 = 10;  % 10=Nyquist, By default, the reference scale for
                     % freqwavelet has center frequency 0.1
freq_step = max_freqDiv10/M;
min_freqDiv10 = freq_step*start_index;
scales = 1./linspace(min_freqDiv10,max_freqDiv10,M-start_index+1);
wvlt = {'cauchy',cauch_alpha};

% Set peak-picking parameters
med_wlen = 21; % Moving window length for median calculation
th_fac = 1.34; % Factor on moving median
th_fac_gab = 1.24; % Factor on moving median

% Prepare matrices for error measures
P = zeros(length(allwavsCell),3);
R = zeros(length(allwavsCell),3);
F = zeros(length(allwavsCell),3);


% Loop over signals
for  ii=2:length(allwavsCell)
  ii
% Select file and load signal
wavfile1 = allwavsCell{ii};
[~,filename1,ext1] = fileparts(wavfile1);
[f,fs] = audioread(wavfile1);
Ls = length(f);

% Define wavelet filterbank
[gs,as,fc,L,info] = waveletfilters(Ls,scales,wvlt,'uniform','repeat',...
                     'energy', 'delay',delays, 'redtar', redundancy);


% Load ground truth
txtfile = allannotCell{ii};
onset_times_gt = dlmread(txtfile);
loc_max_gt = (onset_times_gt/as(1)*fs);


% Calculate wavelet coefficients
c_orig = ufilterbank(f,gs,as);
abss =(abs(c_orig(:,(start_index+1):end)));
[N,Ms] = size(abss);

% Calculate "spectral flux" in wavelet coefficients
sum_up_chng_wvlt = sum(max(abss(2:end,:)-abss(1:(end-1),:),0),2);


%% Peak Picking
%% We define peaks as local maxima that are larger than twice the local median
movmed_chng_wvlt = movmedian(sum_up_chng_wvlt, med_wlen);
loc_max_pos = zeros(N-1,1);
% Find local maxima
loc_max_pos(2:(end-1)) = ...
              (sum_up_chng_wvlt(2:(end-1)) - sum_up_chng_wvlt(1:(end-2))>0)...
              .*(sum_up_chng_wvlt(2:(end-1)) - sum_up_chng_wvlt(3:(end))>0);
% Compare with moving threshold
pass_thresh = (sum_up_chng_wvlt > th_fac*movmed_chng_wvlt);
loc_max_pos2 = loc_max_pos.*pass_thresh;
onset_times = find(loc_max_pos2)*as(1)/fs;



% Compare estimated onsets with ground truth
[P(ii,1),R(ii,1),F(ii,1)] = onset_dist(onset_times,onset_times_gt);



%% DGT for comparison
% Use the same hopsize as in the wavelet case
Mg = redundancy*as(1);
cdgt = dgtreal(f,{'hann',Mg},as(1),Mg); % This choice gives a tight frame, i.e.
                                        % optimal frame bounds
abss = (abs(cdgt(:,1:floor(Ls/as(1)))'));
[N,Ms] = size(abss);

% Calculate "spectral flux" in dgt coefficients
sum_up_chng_gab = sum(max(abss(2:end,:)-abss(1:(end-1),:),0),2);



%% Peak Picking
%% We define peaks as local maxima that are larger than twice the local median
movmed_chng_gab = movmedian(sum_up_chng_gab, med_wlen);
loc_max_pos = zeros(N-1,1);
% Find local maxima
loc_max_pos(2:(end-1)) = (sum_up_chng_gab(2:(end-1))-sum_up_chng_gab(1:(end-2))>0)...
              .*(sum_up_chng_gab(2:(end-1))-sum_up_chng_gab(3:(end))>0);
% Compare with moving threshold
pass_thresh = (sum_up_chng_gab>th_fac_gab*movmed_chng_gab);
loc_max_pos2 = loc_max_pos.*pass_thresh;
onset_times = find(loc_max_pos2)*as(1)/fs;


% Compare estimated onsets with ground truth
[P(ii,2),R(ii,2),F(ii,2)] = onset_dist(onset_times,onset_times_gt);


%% Compare to MIR Toolbox standard detection
mir_compare = mirevents(wavfile1);
onset_times_mir = mirgetdata(mir_compare);
[P(ii,3),R(ii,3),F(ii,3)] = onset_dist(onset_times_mir,onset_times_gt);

end;

% Exclude first sample
P = P(2:end,:);
R = R(2:end,:);
F = F(2:end,:);

% Save results
save([writepath_onset,'results_exp2.mat'],'P','R','F');

%%
figure(7);
hold on;
mainlinex = zeros(2,1);
mainliney = zeros(2,1);
ticklinex = zeros(2,1);
tickliney = zeros(2,1);
for ii = 1:3
    if ii == 1;
      temp_mat = P;
    elseif ii == 2
      temp_mat = R;
    elseif ii == 3
      temp_mat = F;
    end
    Tmin = min(temp_mat,[],1);
    Tmax = max(temp_mat,[],1);
    Tmed = median(temp_mat,1);

    locy = ii+0.2; %y-axis location
    locxmin = Tmin(2);
    locxmed = Tmed(2);
    locxmax = Tmax(2);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p1=plot(mainlinex,mainliney,'--r');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-r');

    locy = ii; %y-axis location
    locxmin = Tmin(1);
    locxmed = Tmed(1);
    locxmax = Tmax(1);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p2=plot(mainlinex,mainliney,'-k');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-k');


    locy = ii-0.2; %y-axis location
    locxmin = Tmin(3);
    locxmed = Tmed(3);
    locxmax = Tmax(3);
    mainlinex = [locxmin,locxmax];
    mainliney = [locy,locy];
    p3=plot(mainlinex,mainliney, '-.b');
    ticklinex = [locxmin,locxmin];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmed,locxmed];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');
    ticklinex = [locxmax,locxmax];
    tickliney = [locy-0.2,locy+0.2];
    plot(ticklinex,tickliney,'-b');

end

yticks(1:3)
yticklabels({...
          'P', ...
          'R', ...
          'F'...
        })

legend([p1, p2, p3],{'STFT','Proposed WL','MIR Onsets'});
hold off;


%[P,R,F]





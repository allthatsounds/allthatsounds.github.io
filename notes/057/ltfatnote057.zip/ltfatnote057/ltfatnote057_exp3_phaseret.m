% This file reproduces the experiment on phaseless reconstruction with the
% fast Griffin-Lim algorithm, reported in the paper 'Invertible grid-based 
% sampling of wavelet transforms for audio processing' by N. Holighaus, 
% G. Koliander, C. Hollomey, and F. Pillichshammer.
%
% Note that the spectral convergence errors computed in this file do not 
% correspond to the results reported in the paper, but are computed only 
% for monitoring and within method evaluation. These results are not 
% comparable across representations and/or parameter sets. To compute 
% errors for between method comparison from the audio file output of this
% file, please see 'ltfatnote057_exp3_phaseret_results_from_output.m'.
%
% This is the full computation, it may take a while and requires the placement
% of the audiofiles from here: http://ltfat.github.io/notes/057/input.zip in
% the same folder as this script.
% To reproduce Figure 8 from pre-calculated results, use the script
% ltfatnote057_exp3_phaseret_results_from_output.m

% Copyright 2022 Nicki Holighaus, Guenther Koliander, Clara Hollomey
%
% This file is part of the reproducible research addendum of 'Invertible 
% grid-based sampling of wavelet transforms for audio processing' by 
% N. Holighaus, G. Koliander, C. Hollomey, and F. Pillichshammer, hereafter
% referred to as code_ltfatnote057.
%
% code_ltfatnote057 is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by the 
% Free Software Foundation, either version 3 of the License, or (at your 
% option) any later version.
%
% code_ltfatnote057 is distributed in the hope that it will be useful, but 
% WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
% or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License 
% for more details.
%
% You should have received a copy of the GNU General Public License along 
% with code_ltfatnote057. If not, see <https://www.gnu.org/licenses/>.

%% Preparation

clearvars;

disp('--- Used subroutines ---');

which comp_filterbankheapint
which comp_filterbankmaskedheapint
which comp_ufilterbankheapint
which comp_ufilterbankmaskedheapint
which comp_filterbankphasegradfrommag

%% Prepare to load test signal

path = './input/'; % Place your test signal wav files here
listing = dir([path,'*.wav']);
allwavsCell = arrayfun(@(wav) fullfile(path,wav.name),listing,'UniformOutput',0);

writepath_uni = './exp3_phaseret/output_uni/'; % The experiment output will be saved here
if ~exist(writepath_uni, 'dir')
       mkdir(writepath_uni)
end
writepath_class = './exp3_phaseret/output_class/'; % The experiment output will be saved here
if ~exist(writepath_class, 'dir')
       mkdir(writepath_class)
end
writepath_kron = './exp3_phaseret/output_kron/'; % The experiment output will be saved here
if ~exist(writepath_kron, 'dir')
       mkdir(writepath_kron)
end
writepath_gab = './exp3_phaseret/output_gab/'; % The experiment output will be saved here
if ~exist(writepath_gab, 'dir')
       mkdir(writepath_gab)
end

%% Fix number of random inits and some parameters
R = 5; % Number of tested random initializations
Ls = 5*44100;			% Desired signal length
start = 0;				% From sample

wavelet_vec = {{'cauchy'}};
% Uncomment the next line of code for the full experiment, for testing 
% 'cauchy' is sufficient, everything else behaves similarly
% wavelet_vec = {{'cauchy'},{'morlet'},{'morse',2},{'morse',3},{'fbsp',3},{'fbsp',5}};

alphas  = [1000,1000,1000,1000];	% Cauchy wavelet order
morletsigmas = [22.38,22.38,22.38,22.38];
morse2alpha = [999, 999, 999, 999];
morse3alpha = [999, 999, 999, 999];
fbsp3bw = [ 7.9 , 7.9, 7.9, 7.9];
fbsp5bw = [ 5.94 , 5.94, 5.94, 5.94];

param_mat = [ alphas; morletsigmas; morse2alpha; morse3alpha; fbsp3bw; fbsp5bw ];

% This segment is commented, because the results are poor and were not
% reported in the paper.
%
% %% ----------------- Uniform wavelet sampling ----------------
% %% Cauchy wavelet parameters
% 
% filtNos = [180, 125, 90, 70];		% Number of scales
% 
% redundancies = [10, 5, 3, 1.8]; % Target redundancy
% 
% %% Prepare arrays for error and timing results
% 
% SConvPGHI = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));
% Timing = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));
% 
% %% Main section
% for jj=1:numel(filtNos) % Loop over parameter sets. 
%     %Note that uniform sampling has poor frame bounds for red 5 and is not a frame at all for red 3
%     fprintf('WAVELETFILTERS (uniform) alpha=%.2f, filters=%d, red=%.2f \n', alphas(jj), filtNos(jj), redundancies(jj));
%     
%     for ll = 1:numel(wavelet_vec)
%         if param_mat(ll,jj) ~= 0
%             fprintf(['WAVELETTYPE ', wavelet_vec{ll}{1}]);
%             % Initialize wavelet filters and dual filters
%             if strcmp(wavelet_vec{ll}(1),'morse')
%                 wletCell = [wavelet_vec{ll}(1),param_mat(ll,jj),wavelet_vec{ll}(2:end)];
%             else
%                 wletCell = [wavelet_vec{ll},param_mat(ll,jj)];
%             end
%             [gs,as,fc,L,info] = waveletfilters(Ls,2.^linspace(6,-3.3,filtNos(jj)),wletCell,'redtar', redundancies(jj),'uniform');
%             gs = comp_filterbank_pre(gs,as,L);
%             gd = filterbankrealdual(gs,as, L,'asfreqfilter');
%             F = frame('ufilterbankreal',gs,as,numel(gs));
%             Fd = frame('ufilterbankreal',gd,as,numel(gs));
%             
%             wName = wletCell{1};
%             for ii = 2:numel(wletCell)
%                 wName = [wName,'_',num2str(wletCell{ii})];
%             end
%             
%             tfr = info.tfr;
%             
%             for ii=1:numel(allwavsCell) % Loop over files
%                 
%                 % Select file and load
%                 wavfile = allwavsCell{ii};
%                 [~,filename,ext] = fileparts(wavfile);
%                 [f,fs] = wavload(wavfile);
%                 
%                 % Truncate signal and normalize conservatively
%                 f = f(start+1:start+L,1);
%                 f = 0.3*normalize(f,'inf');
%                 
%                 % Write audio file of input signal
%                 filenameW = [writepath_uni,filename,'_ORG.flac'];
%                 audiowrite(filenameW,real(f),fs);
%                 
%                 fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);
%                 
%                 % Compute coefficients
%                 c_orig = framenative2coef(F,ufilterbank(f,gs,as));
%                 abss = abs(c_orig);
%                 N = numel(abss);
%      
%                 %%  ----------  Fast Griffin-Lim reconstruction  ----------
%                 
%                 % Iterative phaseless reconstruction using fast Griffin-Lim
%                 tic;
%                 % The below tries to choose the best among R random inits
%                 % and zero init
%                 res = inf*ones(R+1,1);
%                 res_tmp = inf;
%                 coef = abss;
%                 coef_init = coef;
%                 for kk = 1:R+1
%                     if kk == 1
%                         phase = ones(N,1);
%                     else
%                         phase = exp(2*pi*1i.*rand(N,1));
%                     end               
%                     [fhat4,relres,~,c] = frsynabs(F,coef_init.*phase,L,'fgriflim','Fd',Fd,'input','maxit',20,'print');
%                     res(kk) = relres(end);
%                     if res(kk) < res_tmp
%                         res_tmp = relres(end);
%                         coef = c; 
%                     end
%                 end
%                 disp('-------------------')
%                 fhat4 = frsynabs(F,coef,L,'fgriflim','Fd',Fd,'input','maxit',130,'print');
%                 timeWFGLIM = toc;
%                 
%                 % Compute spectral convergence error, save error and timing
%                 cproj = framenative2coef(F,ufilterbank(fhat4,gs,as));
%                 Cdb4 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
%                 SConvPGHI(ii,jj,ll) = Cdb4;
%                 Timing(ii,jj,ll) = timeWFGLIM;
%                 
%                 % Write output file
%                 clear cproj ctemp;
%                 filenameW = [writepath_uni,filename,'_red_',num2str(redundancies(jj)),'_FGLIM_',wName,'.flac'];
%                 audiowrite(filenameW,real(fhat4),fs);
%                 clear fhat4;
%                 
%                 % Print error values
%                 fprintf('FGLIM zeros init C=%.2f dB\n',Cdb4);
%                 
%                 clear timeWPGHI timeWFGLIM timeifiltW;
%                 
%             end
%         end
%     end
% end
% 
% % Uncomment to save results
% save([writepath_uni,'results_exp3_uniform.mat'],'SConvPGHI','-v7.3');
% save([writepath_uni,'timing_exp3_uniform.mat'],'Timing','-v7.3');

%% ----------------- Classical nonuniform wavelet sampling ----------------
%% Cauchy wavelet parameters

filtNos = [180, 125, 90, 70];		% Number of scales

redundancies = [10, 5, 3, 1.8]; % Target redundancy

%% Prepare arrays for error and timing results

SConvPGHI = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));
Timing = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));

%% Main section
for jj=1:numel(filtNos) % Loop over parameter sets
    fprintf('WAVELETFILTERS (classical) alpha=%.2f, filters=%d, red=%.2f \n', alphas(jj), filtNos(jj), redundancies(jj));
    
    for ll = 1:numel(wavelet_vec)
        if param_mat(ll,jj) ~= 0
            fprintf(['WAVELETTYPE ', wavelet_vec{ll}{1}]);
            % Initialize wavelet filters and dual filters
            if strcmp(wavelet_vec{ll}(1),'morse')
                wletCell = [wavelet_vec{ll}(1),param_mat(ll,jj),wavelet_vec{ll}(2:end)];
            else
                wletCell = [wavelet_vec{ll},param_mat(ll,jj)];
            end
            [gs,as,fc,L,info] = waveletfilters(Ls,2.^linspace(6,-3.3,filtNos(jj)),wletCell, 'redtar', redundancies(jj),'fractional');
            gs = comp_filterbank_pre(gs,as,L);
            F = frame('filterbankreal',gs,as,numel(gs));
            Fd = @(coef) frsyniter(F,coef,'tol',1e-5);
            
            wName = wletCell{1};
            for ii = 2:numel(wletCell)
                wName = [wName,'_',num2str(wletCell{ii})];
            end
            
            tfr = info.tfr;
            
            for ii=1:numel(allwavsCell) % Loop over files
                
                % Select file and load
                wavfile = allwavsCell{ii};
                [~,filename,ext] = fileparts(wavfile);
                [f,fs] = wavload(wavfile);
                
                % Truncate signal and normalize conservatively
                f = f(start+1:start+L,1);
                f = 0.3*normalize(f,'inf');
                
                % Write audio file of input signal
                filenameW = [writepath_class,filename,'_ORG.flac'];
                audiowrite(filenameW,real(f),fs);
                
                fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);
                
                % Compute coefficients
                c_orig = framenative2coef(F,filterbank(f,gs,as));
                abss = abs(c_orig);
                N = numel(abss);
     
                %%  ----------  Fast Griffin-Lim reconstruction  ----------
                
                % Iterative phaseless reconstruction using fast Griffin-Lim
                tic;
                % The below tries to choose the best among R random inits
                % and zero init
                res = inf*ones(R+1,1);
                res_tmp = inf;
                coef = abss;
                coef_init = coef;
                for kk = 1:R+1
                    if kk == 1
                        phase = ones(N,1);
                    else
                        phase = exp(2*pi*1i.*rand(N,1));
                    end               
                    [fhat4,relres,~,c] = frsynabs(F,coef_init.*phase,L,'fgriflim','Fd',Fd,'input','maxit',20,'print');
                    res(kk) = relres(end);
                    if res(kk) < res_tmp
                        res_tmp = relres(end);
                        coef = c; 
                    end
                end
                disp('-------------------')
                fhat4 = frsynabs(F,coef,L,'fgriflim','Fd',Fd,'input','maxit',130,'print');
                timeWFGLIM = toc;
                
                % Compute spectral convergence error, save error and timing
                cproj = framenative2coef(F,filterbank(fhat4,gs,as));
                Cdb4 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
                SConvPGHI(ii,jj,ll) = Cdb4;
                Timing(ii,jj,ll) = timeWFGLIM;
                
                % Write output file
                clear cproj ctemp;
                filenameW = [writepath_class,filename,'_red_',num2str(redundancies(jj)),'_FGLIM_',wName,'.flac'];
                audiowrite(filenameW,real(fhat4),fs);
                clear fhat4;
                
                % Print error values
                fprintf('FGLIM zeros init C=%.2f dB\n',Cdb4);
                
                clear timeWPGHI timeWFGLIM timeifiltW;
                
            end
        end
    end
end

% Uncomment to save results
save([writepath_class,'results_exp3_classical.mat'],'SConvPGHI','-v7.3');
save([writepath_class,'timing_exp3_classical.mat'],'Timing','-v7.3');

%% ----------------- Kronecker type uniform wavelet sampling ----------------

%% Cauchy wavelet parameters
% Specify golden Kronecker sequence delays
alpha = 1-2/(1+sqrt(5)); % 1-1/(goldenratio)
delays = @(n,a) a*(mod(n*alpha+.5,1)-.5);

% Original parameters
filtNos = [1369,968,750,580];        % Number of scales
start_index = [17,13,11,9];       % Starting index (set manually)
redundancies = [10, 5, 3, 1.8]; % Target redundancy

a_array = filtNos./redundancies;	
max_freqDiv10 = 10;  % 10=Nyquist, set max freq to Nyquist
freq_step = max_freqDiv10/filtNos(1); % The frequency step equals the maximum
                                      % frequency divided by the number of desired
                                      % channels.

min_freqDiv10 = freq_step*start_index(1); % Center frequency of minimum true
                                               % wavelet channels
scales = 1./linspace(min_freqDiv10,max_freqDiv10,filtNos(1)-start_index(1)+1);

%% Prepare arrays for error and timing results

SConvPGHI = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));
Timing = zeros(numel(allwavsCell),numel(alphas),numel(wavelet_vec));

%% Main section
for jj=1:numel(filtNos) % Loop over parameter sets
    fprintf('WAVELETFILTERS alpha=%.2f, filters=%d, a=%.2f \n', alphas(jj), filtNos(jj), a_array(jj));
    
    for ll = 1:numel(wavelet_vec)
        if param_mat(ll,jj) ~= 0
            fprintf(['WAVELETTYPE ', wavelet_vec{ll}{1}]);
            % Initialize wavelet filters and dual filters
            if strcmp(wavelet_vec{ll}(1),'morse')
                wletCell = [wavelet_vec{ll}(1),param_mat(ll,jj),wavelet_vec{ll}(2:end)];
            else
                wletCell = [wavelet_vec{ll},param_mat(ll,jj)];
            end
            [gs,as,fc,L,info] = waveletfilters(Ls,scales,wletCell,'uniform',...
            'repeat','energy', 'delay',delays, 'redtar', redundancies(jj));
            disp(['Length change: ',num2str(L-Ls)]);
            gs = comp_filterbank_pre(gs,as,L);
            gd = filterbankrealdual(gs,as, L,'asfreqfilter','batchsize',350);
            F = frame('ufilterbankreal',gs,as,numel(gs));
            Fd = frame('ufilterbankreal',gd,as,numel(gs));
            
            wName = wletCell{1};
            for ii = 2:numel(wletCell)
                wName = [wName,'_',num2str(wletCell{ii})];
            end
            
            tfr = info.tfr;
            
            for ii=1:numel(allwavsCell) % Loop over files
                
                % Select file and load
                wavfile = allwavsCell{ii};
                [~,filename,ext] = fileparts(wavfile);
                [f,fs] = wavload(wavfile);
                
                % Truncate signal and normalize conservatively
                f = f(start+1:start+L,1);
                f = 0.3*normalize(f,'inf');
                
                % Write audio file of input signal
                filenameW = [writepath_kron,filename,'_ORG.flac'];
                audiowrite(filenameW,real(f),fs);
                
                fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);
                
                % Compute coefficients
                c_orig = ufilterbank(f,gs,as);
                abss = abs(c_orig);
                [N,M] = size(abss);
                
                %%  ----------  Fast Griffin-Lim reconstruction  ----------
                
                % Iterative phaseless reconstruction using fast Griffin-Lim
                tic;
                % The below tries to choose the best among R random inits
                % and zero init
                res = inf*ones(R+1,1);
                res_tmp = inf;
                coef = framenative2coef(F,abss);
                coef_init = coef;
                for kk = 1:R+1
                    if kk == 1
                        phase = ones(N*M,1);
                    else
                        phase = exp(2*pi*1i.*rand(N*M,1));
                    end
                    [fhat4,relres,~,c] = frsynabs(F,coef_init.*phase,L,'fgriflim','Fd',Fd,'input','maxit',20,'print');
                    res(kk) = relres(end);
                    if res(kk) < res_tmp
                        res_tmp = relres(end);
                        coef = c; 
                    end
                end
                disp('-------------------')
                fhat4 = frsynabs(F,coef,L,'fgriflim','Fd',Fd,'input','maxit',130,'print');
                % Uncomment the next line if zero initialization is desired
                % instead
                timeWFGLIM = toc;
                
                % Compute spectral convergence error, save error and timing
                cproj = ufilterbank(fhat4,gs,as);
                Cdb4 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
                SConvPGHI(ii,jj,ll) = Cdb4;
                Timing(ii,jj,ll) = timeWFGLIM;
                
                % Write output file
                clear cproj ctemp;
                filenameW = [writepath_kron,filename,'_red_',num2str(redundancies(jj)),'_FGLIM_',wName,'.flac'];
                audiowrite(filenameW,real(fhat4),fs);
                clear fhat4;
                
                % Print error values
                fprintf('FGLIM zeros init C=%.2f dB\n',Cdb4);
                
                clear timeWPGHI timeWFGLIM timeifiltW;
                
            end
        end
    end
end

% Uncomment to save results
save([writepath_kron,'results_exp3_kron.mat'],'SConvPGHI','-v7.3');
save([writepath_kron,'timing_exp3_kron.mat'],'Timing','-v7.3');

%% ----------------- Gabor phase reconstruction --------------------------

redundancies = [10, 5, 3, 1.8]; % Target redundancy

% Select numbers a,M with nice prime factors and approximately the same a*M
as = [288,384,512,640];
Ms = [2880,1920,1536,1152];

Lg = 1536; % Length of analysis window
g = firwin('hann',Lg); % Generate analysis window

%% Prepare arrays for error and timing results

SConvPGHI = zeros(numel(allwavsCell), 3);
Timing = zeros(numel(allwavsCell), 3);

%% Main section
for jj=1:numel(Ms) % Loop over parameter sets
    fprintf('GABOR a=%d, M=%d, red=%.2f \n', as(jj), Ms(jj), redundancies(jj));
    
    L = dgtlength(Ls,as(jj),Ms(jj));
    gd = gabdual(g,as(jj),Ms(jj));
            
    wName = 'hann1536';
    tfr = as(jj)*Ms(jj)/L;
    
    F = frame('dgtreal',g,as(jj),Ms(jj));
    Fd = frame('dgtreal',gd,as(jj),Ms(jj));
            
    for ii=1:numel(allwavsCell) % Loop over files
        
        % Select file and load
        wavfile = allwavsCell{ii};
        [~,filename,ext] = fileparts(wavfile);
        [f,fs] = wavload(wavfile);
        
        % Truncate signal and normalize conservatively
        f = f(start+1:start+L,1);
        f = 0.3*normalize(f,'inf');
        
        % Write audio file of input signal
        filenameW = [writepath_gab,filename,'_ORG.flac'];
        audiowrite(filenameW,real(f),fs);
        
        fprintf('\n--------------------------------%s--------------------------------------\n',wavfile);
        
        % Compute coefficients
        c_orig = framenative2coef(F,dgtreal(f,g,as(jj),Ms(jj)));
        abss = abs(c_orig);
        N = numel(abss);
        
        %%  ----------  Fast Griffin-Lim reconstruction  ----------
        
        % Iterative phaseless reconstruction using fast Griffin-Lim
        tic;
        % The below tries to choose the best among R random inits and zero
        % init
        res = inf*ones(R+1,1);
        res_tmp = inf;
        coef = abss;
        coef_init = coef;
        for kk = 1:R+1
            if kk == 1
                phase = ones(N,1);
            else
                phase = exp(2*pi*1i.*rand(N,1));
            end
            [fhat4,relres,~,c] = frsynabs(F,coef_init.*phase,L,'fgriflim','Fd',Fd,'input','maxit',20,'print');
            res(kk) = relres(end);
            if res(kk) < res_tmp
                res_tmp = relres(end);
                coef = c;
            end
        end
        disp('-------------------')
        fhat4 = frsynabs(F,coef,L,'fgriflim','Fd',Fd,'input','maxit',130,'print');
        timeWFGLIM = toc;
        
        % Compute spectral convergence error, save error and timing
        cproj = framenative2coef(F,dgtreal(fhat4,g,as(jj),Ms(jj)));
        Cdb4 = 20*log10( norm(abs((c_orig)) - abs((cproj)),'fro' )/norm( abs((c_orig)),'fro') );
        SConvPGHI(ii,jj) = Cdb4;
        Timing(ii,jj) = timeWFGLIM;
        
        % Write output file
        clear cproj ctemp;
        filenameW = [writepath_gab,filename,'_red_',num2str(redundancies(jj)),'_FGLIM_',wName,'.flac'];
        audiowrite(filenameW,real(fhat4),fs);
        clear fhat4;
        
        % Print error values
        fprintf('FGLIM zeros init C=%.2f dB\n',Cdb4);
        
        clear timeWPGHI timeWFGLIM timeifiltW;
        
    end
end

% Uncomment to save results
save([writepath_gab,'results_exp3_gabor.mat'],'SConvPGHI','-v7.3');
save([writepath_gab,'timing_exp3_gabor.mat'],'Timing','-v7.3');
